package propertymanager;

// apurutiini, jotta ohjelma voidaan käynnistää IDEA:sta Play-napilla
// ilman Javan modulepath-säätöjä
public class Main {
    public static void main(String[] args) {
        MainApp.launch(MainApp.class, args);
    }
}