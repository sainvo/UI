package propertymanager;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.shape.Rectangle;

public class SearchResultController {

    @FXML
    private Rectangle tausta;

    @FXML
    private ImageView kuva;

    @FXML
    private Label kohde;

    @FXML
    private Label kuvaus;

    @FXML
    private Label kuvaus2;

    @FXML
    void activate(MouseEvent event) {

    }

    @FXML
    void deactivate(MouseEvent event) {

    }

}
